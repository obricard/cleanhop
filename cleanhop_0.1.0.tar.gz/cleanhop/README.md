# cleanhop
Index hopping correction for scRNAseq.

Remove potential misassigned reads due to index hopping in single cell RNAseq data generated with combinatorial dual indexes.
